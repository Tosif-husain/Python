import sqlite3

# Step 1: Connect to an in-memory database
conn = sqlite3.connect(":memory:")
cursor = conn.cursor()

# Step 2: Create the student_grades table
cursor.execute("""
CREATE TABLE student_grades (
    Student_ID INTEGER,
    Subject TEXT,
    Grade TEXT
)
""")

# Step 3: Insert 6 records
records = [
    (12, "Math", "A"),
    (12, "Science", "B+"),
    (13, "Math", "B"),
    (14, "Science", "A"),
    (12, "English", "A-"),
    (13, "English", "C")
]

cursor.executemany("INSERT INTO student_grades (Student_ID, Subject, Grade) VALUES (?, ?, ?)", records)

# Step 4: Display grades of student with ID 12
cursor.execute("SELECT Subject, Grade FROM student_grades WHERE Student_ID = 12")
grades = cursor.fetchall()

print("Grades of student with ID 12:")
for subject, grade in grades:
    print(f"{subject}: {grade}")

# Close the connection
conn.close()
