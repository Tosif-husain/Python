from tkinter import *
import sqlite3

# Create database and table if it doesn't exist
conn = sqlite3.connect('address_book.db')
c = conn.cursor()
c.execute('''CREATE TABLE IF NOT EXISTS addresses (
    fname TEXT,
    lname TEXT,
    address TEXT,
    city TEXT,
    state TEXT,
    zipcode INTEGER
)''')
conn.commit()
conn.close()

# Submit function
def submit():
    conn = sqlite3.connect('address_book.db')
    c = conn.cursor()

    c.execute("INSERT INTO addresses VALUES (:fname, :lname, :address, :city, :state, :zipcode)",
              {
                  'fname': fname.get(),
                  'lname': lname.get(),
                  'address': address.get(),
                  'city': city.get(),
                  'state': state.get(),
                  'zipcode': zipcode.get()
              })

    conn.commit()
    conn.close()

    fname.delete(0, END)
    lname.delete(0, END)
    address.delete(0, END)
    city.delete(0, END)
    state.delete(0, END)
    zipcode.delete(0, END)

# Query function
def query():
    conn = sqlite3.connect('address_book.db')
    c = conn.cursor()

    c.execute("SELECT *, oid FROM addresses")
    records = c.fetchall()

    print_record = ''
    for record in records:
        print_record += f"{record}\n"

    query_label = Label(root, text=print_record, justify=LEFT, anchor="w")
    query_label.grid(row=9, column=0, columnspan=2, sticky="w", padx=10)

    conn.commit()
    conn.close()

# GUI setup
root = Tk()
root.title("DATABASE PROJECT")
root.geometry("733x450")

main_label = Label(root, text="DATABASE", relief=SUNKEN)
main_label.grid(pady=10, padx=100, row=0, column=1)

fname = Entry(root, width=30)
lname = Entry(root, width=30)
address = Entry(root, width=30)
city = Entry(root, width=30)
state = Entry(root, width=30)
zipcode = Entry(root, width=30)

fname.grid(row=1, column=1, padx=20)
lname.grid(row=2, column=1)
address.grid(row=3, column=1)
city.grid(row=4, column=1)
state.grid(row=5, column=1)
zipcode.grid(row=6, column=1)

fname_label = Label(root, text="FIRST NAME")
lname_label = Label(root, text="LAST NAME")
address_label = Label(root, text="ADDRESS")
city_label = Label(root, text="CITY")
state_label = Label(root, text="STATE")
zipcode_label = Label(root, text="ZIPCODE")

fname_label.grid(row=1, column=0)
lname_label.grid(row=2, column=0)
address_label.grid(row=3, column=0)
city_label.grid(row=4, column=0)
state_label.grid(row=5, column=0)
zipcode_label.grid(row=6, column=0)

submit_btn = Button(root, text="Add Record To Database", command=submit)
submit_btn.grid(row=7, column=0, pady=10, padx=10, columnspan=2, ipadx=100)

query_btn = Button(root, text="Show Records", command=query)
query_btn.grid(row=8, column=0, columnspan=2, padx=10, pady=10, ipadx=137)

root.mainloop()
