import sqlite3

# conn = sqlite3.connect(':memory:')
conn = sqlite3.connect('customer.db')

# create a cursor
c = conn.cursor()

many_customer = [
                 ('Wes','brown','webbrown'),
                 ('tosif','husain','ansari'),
                 ('tohid','husain','ansari')
                ]

# create a table
c.executemany("INSERT INTO customers VALUES (?,?,?)",many_customer)

c.execute("SELECT * FROM customers")

# print(c.fetchall())
# print(c.fetchone())
# print(c.fetchmany(2))


items = c.fetchall()

for item in items:
  print(items)
  break

conn.commit()

conn.close()
