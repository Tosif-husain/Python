# fruits = [] 

# f1 = input("enter fruit 1: ")
# fruits.append(f1)
# f2 = input("enter fruit 2: ")
# fruits.append(f2)
# f3 = input("enter fruit 3: ")
# fruits.append(f3)

# print(fruits)

# 2 sorted method problem...

# marks = [] 

# f1 = input("enter marks 1: ")
# marks.append(f1)
# f2 = input("enter marks 2: ")
# marks.append(f2)
# f3 = input("enter marks 3: ")
# marks.append(f3)

# marks.sort()

# print(marks)
# print(type(marks))

# 3 sum of list problem...

# a = (1,2,3)

# print(sum(a))

# 4 count 0 in tuple problem...

c1 = (1,0,4,0,2,0)

n = c1.count(0)

print(n)



