from tkinter import *

root = Tk()
root.title("Home page")
root.maxsize(width=600,height=300)

def delete():
  lst.delete(ANCHOR)

lst = Listbox(root,width=20)
items = ["apple","mango","banana"]

for i in items:
  lst.insert(END,i)
lst.pack()

btn = Button(root,text="Delete",command=delete).pack()

root.mainloop()
