from matplotlib import pyplot as plt

x = (1,2,3,4)
y = (1,2,3,4)

plt.pie(x,y)