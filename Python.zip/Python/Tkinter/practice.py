from matplotlib import pyplot as plt

x = [1,2,3,4]
y = [4,6,3,7]

plt.plot(x,y,color='red')

plt.title("Tosif husain")
plt.xlabel("range")
plt.ylabel("value")

plt.show()