from tkinter import *
from PIL import ImageTk,Image

root = Tk()
root.title("Images")
root.iconbitmap('C:/Users/lenovo/Desktop/SEM-4/Python/Tkinter/image.ico')
root.maxsize(width=800,height=500)

my_img = ImageTk.PhotoImage(Image.open("My_photo.webp"))
my_label = Label(image=my_img)
my_label.pack()


button_quit = Button(root, text="Exit program",command=root.quit,fg="black",bg="lightblue",padx=10,pady=10,borderwidth=5)
button_quit.pack()

root.mainloop()


