# from tkinter import *

# root = Tk()

# e = Entry(root,width=50,bg="black",fg="white",borderwidth=5)
# e.insert(0,"Enter your Name: ")
# e.pack()

# def buttonClick():
#   myLabel = Label(root,text="HELLO! "+e.get())
#   myLabel.pack()
  
# myButton = Button(root,text="Enter name",fg="blue",command=buttonClick,padx=10,pady=10)
# myButton.pack()

# root.mainloop()

from tkinter import *

root = Tk()
root.title("Entry")

# Create a label above the Entry
label = Label(root, text="Enter your Name:")
label.pack()

e = Entry(root, width=50, bg="black", fg="white", borderwidth=5)
e.pack()

def buttonClick():
    myLabel = Label(root, text="HELLO! " + e.get())
    myLabel.pack()

myButton = Button(root, text="Enter name", fg="blue", command=buttonClick, padx=10, pady=10)
myButton.pack()

root.mainloop()



