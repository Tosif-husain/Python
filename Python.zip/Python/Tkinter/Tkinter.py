from tkinter import *

root = Tk()

myLable = Label(root,text="Tosif husain",width=100,height=40)

myLable.pack()

root.mainloop()