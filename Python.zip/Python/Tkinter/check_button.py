from tkinter import *

root = Tk()

def funk():
    print(f"value",ch1.get())
    print(ch2.get())


ch1 = IntVar()
ch2 = IntVar()

btn = Button(root,text="click",command=funk)
btn.pack()

check_button = Checkbutton(root,text="male",fg="red",variable=ch1,onvalue=1,offvalue=0).pack()
check_button2 = Checkbutton(root,text="female",fg="blue",variable=ch2,onvalue=1,offvalue=0).pack()

root.mainloop()
