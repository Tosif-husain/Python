from tkinter import *
import sqlite3

conn = sqlite3.connect('registration.db')
c = conn.cursor()

c.execute('SELECT * FROM users')
rows = c.fetchall()

for row in rows:
  print(row)

conn.commit()
conn.close()


def Registration():
  conn = sqlite3.connect('registration.db')
  c = conn.cursor()
  
  name = e2.get()
  age = e3.get()
  gender = e4.get()
  email = e5.get()
  mobile = e6.get()
  
  c.execute('INSERT INTO users (name,age,gender,email,mobile)VALUES (?,?,?,?,?)',(name,age,gender,email,mobile))
  
  conn.commit()
  conn.close()
  
  e2.delete(0,END)
  e3.delete(0,END)
  e4.delete(0,END)
  e5.delete(0,END)
  e6.delete(0,END)

root = Tk()
root.title("REGISTRATION FORM")
root.geometry("400x300")

l1 = Label(root, text="PERSONAL DETAILS",relief=SUNKEN)
l2 = Label(root, text="Name")
l3 = Label(root, text="Age")
l4 = Label(root, text="Gender")
l5 = Label(root, text="Email")
l6 = Label(root, text="Mobile Number")

e2 = Entry(root)
e3 = Entry(root)
e4 = Entry(root)
e5 = Entry(root)
e6 = Entry(root)

b1 = Button(root, text="Submit Here", command=Registration)

l1.grid(row=0, column=1, pady=10)
l2.grid(row=1, column=0, pady=10)
l3.grid(row=2, column=0, pady=10)
l4.grid(row=3, column=0, pady=10)
l5.grid(row=4, column=0, pady=10)
l6.grid(row=5, column=0, pady=10)

e2.grid(row=1, column=1)
e3.grid(row=2, column=1)
e4.grid(row=3, column=1)
e5.grid(row=4, column=1)
e6.grid(row=5, column=1)

b1.grid(row=6, column=1, pady=5)

root.mainloop()
