from tkinter import *

root = Tk()

def func():
  print(var.get())

var = IntVar()

radio1 = Radiobutton(root,text="student",value=0,variable=var).pack()
radio1 = Radiobutton(root,text="worker",value=1,variable=var).pack()

btn = Button(root,text="Submit",command=func).pack()

root.mainloop()