from tkinter import *
root = Tk()

myLabel1 = Label(root,text="Tosif husain")
myLabel2 = Label(root,text="Learning Python")
myLabel3 = Label(root,text="1earning Python")

myLabel1.grid(row="0",column="0")
myLabel2.grid(row="2",column="0")
myLabel3.grid(row="1",column="0")


root.mainloop()

