# from tkinter import *
# from tkinter import messagebox

# root = Tk()

# def func():
#   if var.get() == "":
#     messagebox.showwarning("Warning","Empty Box")
#   else:
#     messagebox.askyesno("ask","do you want to exit")
#     root.destroy()

# var = StringVar()
# ent = Entry(root,textvariable=var).pack()

# btn = Button(root,text="click",command=func).pack()

# root.mainloop()

from tkinter import *
from tkinter import messagebox

root = Tk()
root.title("Home page")
root.maxsize(width=200,height=100)

def my_func():
  if var.get() == "":
    messagebox.showwarning("Warning","Empty box")
  else:
    messagebox.askyesno("ASK","do you want to exit?")
    root.destroy()

var = StringVar()
ent = Entry(root,textvariable=var).pack()

btn = Button(root,text="click",command=my_func).pack()

root.mainloop()