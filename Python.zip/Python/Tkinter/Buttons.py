from tkinter import *

root = Tk()

def clickEvent():
    myLabel = Label(root,text="i clicked buttun and called it from function")
    myLabel.pack()

myButton = Button(root,text="Click Me!",padx=10,pady=10,bg = "#403923",fg="red",command=clickEvent)
myButton.pack()

root.mainloop()