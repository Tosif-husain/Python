# from tkinter import ttk
# from tkinter import *

# root = Tk()

# var = StringVar()
# com = ttk.Combobox(root,width=27)
# com['values'] = ('Jan','Feb')
# com.current(0)
# com['state'] = 'readonly'
# com.place(x=100,y=100)

# root.mainloop()

from tkinter import *
from tkinter import ttk

root = Tk()

var = StringVar()
combo = ttk.Combobox(root,width=20)
combo['values'] = ('jan','feb')
combo.current(0)
combo['state'] = "readonly"
combo.place(x=70,y=10)
combo.grid(row=0,column=0)

root.mainloop()

