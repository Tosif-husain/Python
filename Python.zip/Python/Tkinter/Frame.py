from tkinter import *

root = Tk()

topheader = Frame(root).pack()
bottom = Frame(root).pack()

label = Label(topheader,text="this is header").pack()
label = Label(bottom,text="this is footer").pack(side=BOTTOM)


root.mainloop()