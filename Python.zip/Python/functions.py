# def avg():
#   a = int(input("Enter first number: "))
#   b = int(input("Enter second number: "))
#   c = int(input("Enter third number: "))
  
#   average = (a+b+c)/3
#   print(average)
  
# avg()

# def greet():
#   name = input("enter your name: ")
#   print(f"Good day {name}")

# greet()

# fcatorial...

def factorial(n):
  if(n == 0 or n == 1):
    return 1
  return n * factorial(n-1)

n = int(input("enter number: "))
print(f"factorial of {n} is: {factorial(n)}")