# multiple Inheritance...
# class Employee:
#   company = "ITC"
#   name = "Tosif"
#   salary = 2100000
#   def show(self):
#     print(f"The name of the Employee is {self.name} and salary is {self.salary}")
    
# class coder:
#   language = "Python"
#   def printLanguage(self):
#     print(f"Name of the language is {self.language}")
    
# class Programmer(Employee,coder):
#   company = "ITC Infotech"
  
#   def showLanguage(self):
#     print(f"The name of Company is {self.company} and he is good at {self.language}")
    
# a = Employee()
# b = Programmer()

# b.show()
# b.printLanguage()
# b.showLanguage()

#The use of SUPER keyword...

class Employee:
  def __init__(self):
    print("Constructor of employee")
  a = 1

class Programmer(Employee):
  def __init__(self):
    print("Constructor of Programmer")
  b = 2
    
class Manager(Programmer,Employee):
  def __init__(self):
    super().__init__()
    print("Constructor of Manager")
  c = 3
  
m = Manager()
print(m.a,m.b,m.c)  
    