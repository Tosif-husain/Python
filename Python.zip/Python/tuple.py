# t = (1,2,3,4,5)
# sum = 0

# for i in t:
#   sum += i
# print(sum)

# t = (1,2,(3),(4,5))

# print(t[3][0])

# count method...

# t1 = (1,1,2,3,45,False,"tosif")

# print(t1)

# no = t1.count(1)

# print(no)

# index method...

# t1 = (1,1,2,3,45,False,"tosif")

# i = t1.index("tosif")

# print(i)

# concate method...

# t1 = (1,2,3)
# t2 = ("tosif",5)

# concatenated = t1 + t2

# print(concatenated)

# repeated method...

# t1 = (1,2,3)

# repeated = t1 * 2

# print(repeated)

# min-max method...

# t1 = (1,2,3)

# print(min(t1))
# print(max(t1))





