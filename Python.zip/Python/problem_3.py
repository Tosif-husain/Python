import pyttsx3
engine = pyttsx3.init()
engine.say("I'm Tosif husain learning python programming...")
engine.runAndWait()