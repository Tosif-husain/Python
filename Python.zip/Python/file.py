#file read...

# f = open("file.txt")
# data = f.read()
# print(data)
# f.close()

#file write...

# myStr = "hello world"

# f = open("write.txt","w")

# f.write(myStr)

# f.close()

# read lines...

# f = open("w.txt","r")

# line = f.readlines()

# print(line,type(line))

# f.close()

# read lines using while loop...

# f = open("w.txt","r")

# line = f.readline()

# while(line != ""):
#   print(line)
#   line = f.readline()
  
# f.close()

# f = open("w.txt","r")

# line = f.readline()

# while(line != ""):
#   print(line)
#   line = f.readline()

# f.close()

# problem 1 find word in file...

# f = open("poem.txt","r")

# content = f.read()

# if("twinkle" in content):
#   print("The word twinkle is present in content")
# else:
#   print("The word twinkle is not present in content")
  
# f.close()

# problem 2 write highscore and update in the game...

# import random

# def game():

#   print("You'er playing game...")

#   score = random.randint(1,100)

#   with open("highscore.txt","r") as f:
#     highscore = f.read()
#     if(highscore != ""):
#       highscore = int(highscore)
#     else:
#       highscore = 0
    
#   print(f"Your highscore: {score}")
#   if(score > highscore):
#     with open("highscore.txt","w") as f:
#       f.write(str(score))
#   return score

# game()

# problem 3 write a multiplication table using files...

# def generateTable(n):
#   table = ""
#   for i in range(1,11):
#     table += f"{n} X {i} = {n*i}\n"    
#   with open(f"tables/table_{n}.txt","w") as f:
#     f.write(table)

# for i in range(2,21):
#   generateTable(i)

# problem 4 create any word and replace it with '#'...

# word = "dog"

# with open("animal2.txt","r") as f:
#   content = f.read()
  
# newContent = content.replace(word,"###")

# with open("animal2.txt","w") as f:
#   f.write(newContent)
    
# problem 5 create list of any words and replace it with '#'...

# words = ["apple","banana","mango","orange","papaya"]

# with open("file.txt","r") as f:
#   content = f.read()
  
# for word in words:
#   content = content.replace(word,"#"*len(word))
  
# with open("file.txt","w") as f:
#   f.write(content)
  
# problem 6 create content and find python word in that content...

# with open("poem.txt") as f:
#   content = f.read()
  
# if("python" in content):
#   print("yes")
# else:
#   print("no")

# problem 7 create content and find python word in that contenta and also print line number...

# with open("poem.txt") as f:
#   lines = f.readlines()
  
# lineno = 1

# for line in lines:
#   if("python" in line):
#     print(f"word is present at line number: {lineno}")
#     break
#   lineno += 1

# else:
#   print("not present")

# problem 8 create this.txt and copy that in another file....

# with open("this.txt") as f:
#   content = f.read()
  
# with open("this_copy.txt","w") as f:
#   f.write(content)

# problem 9 create two files and check it wether it is same or not...

# with open("file.txt") as f:
#   content1 = f.read()

# with open("this.txt") as f:
#   content2 = f.read()

# if(content1 == content2):
#   print("its same")
# else:
#   print("Not same")

# problem 10 wipe out content of file...

# with open("this_copy.txt","w") as f:
#   f.write("")
  
  

    

