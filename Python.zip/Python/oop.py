# class student:
#   subject = "English"
#   Class = 12
  
#   def getInfo(self):
#     print(f"subject is {self.subject} and class is {self.Class}")
  
#   @staticmethod
#   def greet():
#     print("Good afternoon")
  
# school = student()
# school.getInfo()
# school.greet()

# problem 1...

# class programmer:
#   company = "microsoft"
  
#   def __init__(self,name,salary,pincode):
#     self.name = name
#     self.salary = salary
#     self.pincode = pincode
    
# p = programmer("Tosif husain",1200000,380028)
# print(p.company,p.name,p.salary,p.pincode)

# p1 = programmer("Arman siddiqui",1000000,380029)
# print(p1.company,p1.name,p1.salary,p1.pincode)

# problem 2...

# class calculator:
  
#   def __init__(self,n):
#     self.n = n
    
#   def square(self):
#     print(f"The square is: {self.n*self.n}")
    
#   def cube(self):
#     print(f"The cube is: {self.n*self.n*self.n}")
    
#   def squareRoot(self):
#     print(f"The squareRoot is: {self.n**1/2}")
    
# ans = calculator(10)
# ans.square()
# ans.cube()
# ans.squareRoot()

# problem 3...

# class greet():
#   @staticmethod
#   def Greet():
#     print("Good afternoon")
    
# g = greet()
# g.Greet()

# problem 4...

# import random
from random import randint

class Train:
  def book(self,trainNo,fro,to):
    print(f"Ticket is booked in train no: {trainNo} from {fro} to {to}")
  
  def getStatus(self,trainNo):
    print(f"Train no: {trainNo} is running on time")
  
  def getFare(self,trainNo,fro,to):
    print(f"Ticket fare in train no: {trainNo} from {fro} to {to} is {randint(255,500)}") 
    
t = Train(12100)
t.book("ahmedabad","mumbai")  
t.getStatus()  
t.book("ahmedabad","mumbai")  