
class bank:
    
    def __init__(self , a_no  ,  h_name , bal): 
        
        self.acc_no = a_no  
        self.holder_name = h_name;  
        self.balance = bal
        
    def deposite(self , amount):
        
        self.balance = self.balance + amount
        print("Amount added , Available balance is " , self.balance)
        
    def withdraw(self , amount):
        
        self.balance = self.balance - amount
        print("Amount withdrawed , Available balance is " , self.balance)
        
    def info(self):
        
 
        print("Account No" , self.acc_no)
        print("Account Holder Name" , self.holder_name)
        print("Account Balance " , self.balance)
        
b1=bank(101,"Abc",23000) 
b1.deposite(500) 
b1.info()
b1.withdraw(200)
b1.info()







