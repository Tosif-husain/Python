# letter = '''Dear <|Name|>
#             you are selected!
#             <|date|>'''
# print(letter.replace("<|Name|>","tosif").replace("<|date|>","4 march 2027"))

# Find two space in String...
# myString = "my name is  Tosif"

# print(myString.find("Tosif"))
# print(myString.replace("  "," "))

# use escape squences...
# Str = "Dear tosif,\n \tYou'er good in programming\n Thanks"
# print(Str)