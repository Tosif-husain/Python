# a = int(input("enter first number: "))
# b = int(input("enter second number: "))

# print("sum of nums: ",a+b)