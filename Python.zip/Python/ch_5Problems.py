#1.Write a program to create dictionary of hindi words with english 

# words = {
#   "kursi" : "table",
#   "haathi" : "elephant",
#   "pankha" : "fen"
# }

# userWords = input("Enter the words you want to meaning of: ")
# print(words[userWords])

# words = {
#   "ek" : "one",
#   "do" : "two",
#   "char" : "four",
#   "teen" : "three",
#   "panch" : "five"
# }

# userWords = input("Please enter hindi numbers 1 to 5 to translate in hindi: ")

# print(words[userWords])

# 2. write a program to input eight numbers from the user and display all the unique numbers(once).

# s = set()

# n = input("Enter numbers 1: ")
# s.add(int(n))
# n = input("Enter number 2: ")
# s.add(int(n))
# n = input("Enter number 3: ")
# s.add(int(n))
# n = input("Enter number 4: ")
# s.add(int(n))
# n = input("Enter number 5: ")
# s.add(int(n))
# n = input("Enter number 6: ")
# s.add(int(n))
# n = input("Enter number 7: ")
# s.add(int(n))
# n = input("Enter number 8: ")
# s.add(int(n))

# print(s)

# setVar = set()

# n = input("Enter Str 1:")
# setVar.add(n)
# n = input("Enter Str 2:")
# setVar.add(n)
# n = input("Enter Str 3:")
# setVar.add(n)
# n = input("Enter Str 4:")
# setVar.add(n)
# n = input("Enter Str 5:")
# setVar.add(n)

# print(setVar)

# 3.what will be output of below set

# s = set()
# s.add(20) #20 == 20.0  output true
# s.add(20.0)
# s.add('20')

# print(len(s)) #output 2

#4.what is type of above..

# s = {}

# print(type(s))

#create empty dictionary with friends name with their selected languages...

d =  {}

name = input("enter friend name: ")
lan = input("enter langauge: ")
d.update({name : lan})

name = input("enter friend name: ")
lan = input("enter language: ")
d.update({name:lan})

name = input("enter friend name: ")
lan = input("enter language: ")
d.update({name:lan})

name = input("enter friend name: ")
lan = input("enter language: ")
d.update({name:lan})

print(d)



