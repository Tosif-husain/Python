# PROBLEM 1...

# n1 = int(input("Enter first number: "))
# n2 = int(input("Enter second number: "))
# n3 = int(input("Enter third number: "))
# n4 = int(input("Enter fourth number: "))

# if(n1 > n2 and n1 > n3 and n1 > n4):
#   print("The gretest number is n1: ",n1)
  
# elif(n2 > n1 and n2 > n3 and n2 > n4):
#   print("The gretest number is n2: ",n2)

# elif(n3 > n1 and n3 > n2 and n3 > n4):
#   print("The gretest number is n3: ",n3)
  
# else:
#   print("The gretest number is n4: ",n4) 

# PROBLEM 2...

# marks1 = float(input("enter subject 1 marks: "))
# marks2 = float(input("enter subject 2 marks: "))
# marks3 = float(input("enter subject 3 marks: "))

# total_percentage = ((100)*(marks1+marks2+marks3))/300

# if(total_percentage >= 40 and marks1 >= 33 and marks2 >= 33 and marks3 >= 33):
#   print("You'er pass with percentage: ",total_percentage)
# else:
#   print("You'er fail, Try again next year: ",total_percentage)

# PROBLEM 3...

# message = input("Enter comment: ")

# p1 = "Make a lot of money"
# p2 = " Buy now"
# p3 = "Subscribe now"
# p4 = "Click this"

# if((p1 in message) or (p2 in message) or (p3 in message) or (p4 in message)):
#   print("this comment is spam ")
  
# else:
#   print("This comment is not spam")

# PROBLEM 4...

# userName = input("Enter username: ")

# if(len(userName) < 10):
#   print("username contains less than 10 charcters")
# else:
#   print("username contains more than 10 charcters")

# PROBLEM 5...

# myList = ["tosif","arman","yasin","anas","kaif"]

# name = input("Enter your name: ")

# if(name in myList):
#   print(name,"you'er selected")
# else:
#   print(name,"sorry you'er not selected")

# PROBLEM 6...

# marks = float(input("Enter your marks: "))

# if(marks >= 90 and marks <= 100):
#   print("You got",marks,"your grade is 'Ex'")
# elif(marks < 90 and marks >= 80):
#   print("You got",marks,"Your grade is 'A'")
# elif(marks >= 70 and marks < 80):
#   print("You got",marks,"Your grade is 'B'")
# elif(marks >= 60 and marks < 70):
#   print("You got",marks,"Your grade is 'C'")
# elif(marks >= 50 and marks < 60):
#   print("You got",marks,"Your grade is 'D'")
# else:
#   print("You got",marks,"Sorry You'er fail")

# PROBLEM 7...

# post = input("Enter post: ")

# if("tosif".lower() in post.lower()):
#   print("this post is talking about you")
# else:
#   print("this post is not talking about you")










