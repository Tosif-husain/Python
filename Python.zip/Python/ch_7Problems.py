# 1. Multiplication Table...

# n = int(input("Enter number for multiplication table: "))

# for i in range(1,11):
#   print(f"{n} X {i} = {n * i}")

# 2. greet them whose names starts with 's' 

# listOfName = ["tosif","arman","anas","yasin"]

# for name in listOfName:
#   if(name.startswith("t")):
#     print(f"Hello! {name}")

# 3. attemp problem one using while loop

# n = int(input("Enter number for multiplication table: "))
# i = 1
# while(i <= 10):
#   print(f"{n} X {i} = {n*i}")
#   i=i+1

# 4. check whether a number is prime or not...

# n = int(input("Enter number to check prime or not: "))

# for i in range(2,n):
#   if(n % i) == 0:
#     print(f"{n} is not prime")
#     break
#   else:
#     print(f"{n} is prime number")
#     break

# 5. sum of n numbers using while loop...

# n = int(input("Enter number: "))

# i = 1
# sum = 0

# while(i <= n):
#   sum += i
#   i+=1
# print(f"sum of {n} is = ",sum)

# 6.factorial using for loop...

# n = int(input("Enter number: "))

# fact = 1
# for i in range(1,n+1):
#   fact *= i
# print(f"factorial of {n} is = ",fact)

# 7. print reverse multiplication table using for loop...

# n = int(input("Enter number: "))

# for i in range(1,11):
#   print(f"{n} X {11-i} = {n*(11-i)}")

# 8. pattern 1...

# n = int(input("Enter numbers: "))

# for i in range(1,n+1):
#   print(" "*(n-i),end = " ")
#   print("*"*(2*i-1),end = " ")
#   print("")

# 8. pattern 2...

# n = int(input("Enter numbers: "))
# for i in range(1,n+1):
#   print("*" * i,end = " ")
#   print(" ")

# 8. pattern 3...

# n = int(input("Enter numbers: "))

# for i in range(1,n+1):
#     if(i==1 or i == n):
#        print("*"*n,end ="")
#     else:
#        print("*",end = "")
#        print(" " * (n-2),end="")
#        print("*",end="")
#     print(" ")

