#1.greatest of three numbers...

# def greatest():
#   n1 = int(input("enter number 1: "))
#   n2 = int(input("enter number 2: "))
#   n3 = int(input("enter number 3: "))
  
#   if(n1 > n2 and n1 > n3):
#     print("number 1 is greatest")
#   elif(n2 > n1 and n2 > n3):
#     print("number 2 is greatest")
#   else:
#     print("number 3 is greatest")
    
# greatest()

#2.convert f into celcious
# def f_to_c(f):
#     return 5 * (f-32)/9
# f = int(input("Enter temperature in F: "))
# c = f_to_c(f)
# print(f"{round(c,2)}°C")

# 3.sum of n numbers...

# def sum(n):
#   if(n == 1):
#     return 1
#   return sum(n-1) + n

# print(sum(3))

# 4.print pettern...

# def pettern(n):
#   if(n == 0):
#     return
#   print("*" * n)
#   pettern(n-1)
  
# pettern(5)

# inches to CM...

# def inch_to_CM(inch):
#   return inch * 2.54
# n = int(input("Enter inch: "))
# print(f"value in CM = {inch_to_CM(n)}")

# 5. remove using strip...

# def rem(l, word):
#   n = []
#   for item in l:
#     if (item != word):
#       n.append(item.strip(word))
#   return n
# l = ["tosif", "arman", "yasin", "an"]

# print(rem(l,"an"))

# 6. multiplication of given number...

def multiplication(n):
  for i in range(1,11):
    print(f"{n} X {i} = {n*i}")
multiplication(10)
    
