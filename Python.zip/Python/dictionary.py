# marks = {
#   "tosif" : 90,
#   "arman" : 95,
#   "yasin" : 85
# }


# print(marks,type(marks))
# print(marks["tosif"])
# print(marks.items())
# print(marks.keys())
# print(marks.values())
# marks.update({"tosif":92})
# print(marks)
# print(marks.get("tosif"))
# print(marks.pop("yasin"))
# print(marks)
 
# len method... 
# l = {0:1,1:"tosif"}
# len(l)
 
# remove method... 
# r = {1,2,3,42,2} 
# r.remove(1)
# print(r)

# union & intersaction method...

s1 = {1,45,2}
s2 = {3,4,5,45}

print(s1.union(s2))
print(s1.intersection(s2))