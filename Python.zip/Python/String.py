# a = float(input("enter first number: "))
# b = float(input("enter sec number: "))
# print("addition = ",a+b)
# print("subtraction = ",a-b)
# print("multiplication = ",a*b)
# print("division = ",a/b)
# print("mudule = ",a%b)

# string = '''hello
# hii
# "how are you ?"
# i'm fine'''

# for charcters in string:
#   print(charcters)

# name = "tosif,arman"
# print(len(name))

# name = "tosif,arman"
# print(name[0:5])

# name = "mango"
# print(name[-3:-1])

# name = "tosif"
# print(name[-4:-2])

name = "tosif@@@ Husain"
print(name.rstrip("@"))
print(name.upper())
print(name.lower())
print(name.replace("tosif","tosifHusain"))
print(name.split(" "))
print(name.count("t"))

heading = "how to become best coder?"
print(len(heading.capitalize()))

heading = "how to become best coder?"
print(len(heading.center(50)))
print(heading.endswith("."))
print(heading.endswith("?"))
print(heading.endswith("to",3,6))


str = "he's my best friend and he is very loyal to me."
print(str.find("is"))
print(str.index("istt")) #// it's show an error and it's use for error handling...

str1 = "WelcomeToTheConsole020" 
print(str1.isalnum())
print(str1.isalpha())
print(str1.islower())
print(str1.isupper())

str2 = "    "
print(str2.isspace())

str3 = "IsTitle"
print(str3.istitle())

str4 = "Start With"
print(str4.startswith("Start"))
print(str4.swapcase())