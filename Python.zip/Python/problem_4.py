import os

# Specify the directory path
directory_path = input("Enter the directory path: ")

# Check if the specified path exists
if os.path.exists(directory_path):
    print(f"Contents of the directory '{directory_path}':")
    
    # List the contents of the directory
    for item in os.listdir(directory_path):
        print(item)
else:
    print(f"The directory '{directory_path}' does not exist.")
