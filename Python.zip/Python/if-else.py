# a = int(input("enter your age: "))
# print("your age is: ",a)

# if(a > 18):
#   print("you can drive ")
# else:
#   print("you can not")

num = int(input("enter number: "))

if(num < 0):
  print("num is negative")
elif(num == 0):
  print("num is zero")
else:
  print("num is positive")
  