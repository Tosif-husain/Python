# x = int(input("enter value for cases: "))

# match x:
#   case 0: 
#     print("x is zero")
#   case 2:
#     print("case is 2")
#   case _:
#     print(x)

marks = int(input("enter your marks: "))

match marks:
  case _ if marks <= 30:
    print("you'er fail")
  case _ if marks > 30 and marks <= 40:
    print("your grade is F")
  case _ if marks > 40 and marks <= 50:
    print("your grade is E")
  case _ if marks > 50 and marks <= 60:
    print("your grade is D")
  case _ if marks > 60 and marks <= 70:
    print("your grade is C")
  case _ if marks > 70 and marks <= 80:
    print("your grade is B")
  case _ if marks > 80 and marks <= 90:
    print("your grade is A")
  case _ if marks > 90 and marks <= 100:
    print("your grade is A++")
  case _:
    print("Invalid number")