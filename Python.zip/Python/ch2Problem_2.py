# a = int(input("enter first number: "))
# b = int(input("enter second number: "))

# print("reminder of the numbers: ", a % b)

# a = input("enter anything for type: ")

# print(type(a))

# compare 2 operators...

# a = int(input("enter number one: "))
# b = int(input("enter number two: "))

# print("a is greater than b: ", a > b)

# average of two numbers...

# a = int(input("enter number a: "))
# b = int(input("enter number b: "))

# print("average of these two numbers is: ", (a+b)/2)

# find square of numbers entered by users...

a = int(input("enter value of a: "))

print("squar of number: ",a**a)
