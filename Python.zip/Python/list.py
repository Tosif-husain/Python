# MIMP LISTS ARE MUTABLE

# append method...

# myStr = ["apple","apple","mango",12,12.43]

# myStr.append("end of the list")

# print(myStr)

# sort method...

# numList = [9,7,6,3,2,1,7]

# # for i in numList:
# #   print(i)
# # isinstance(i,list)

# # numList.sort()
# # numList.reverse()
# # numList.insert(2,"tosif")
# # numList.pop(1)
# # numList.remove(3)
# numList.count()

# print(numList)

# 1.create a list of 10 numbers entered by users...

# numbers = []
# for i in range(5):
#   num = float(input("enter numbers: "))
#   numbers.append(num)
# print("The list of numbers is: ",numbers)


# 2.check wether string list is palindrome or not... 

def is_palindrome(string_list):
    return string_list == string_list[::-1]

# Input from the user
n = int(input("Enter the number of strings in the list: "))
strings = [input(f"Enter string {i+1}: ") for i in range(n)]

# Check if the list is a palindrome
if is_palindrome(strings):
    print("The string list is a palindrome.")
else:
    print("The string list is not a palindrome.")


