import random
'''
-1 water
0 gun
1 for snake
'''
computer = random.choice([-1,0,1])
yourChoice = input("Enter your choice (snake, water, gun): ")
yourDict = {"water" : -1, "gun" : 0, "snake" : 1}
reverseDict = {1 : "snake", 0 : "gun", -1 : "water"}

you = yourDict[yourChoice]

print(f"You chose {reverseDict[you]}\n Computer chose {reverseDict[computer]}")

if(computer == you):
  print("Match draw!")
else:
  if(computer == -1 and you == 1):
    print("You win!")
  elif(computer == -1 and you == 0):
    print("You lose!") 
  elif(computer == 1 and you == -1):
    print("You lose!")
  elif(computer == 1 and you == 0):
    print("You win!")
  elif(computer == 0 and you == -1):
    print("You win!")
  elif(computer == 0 and you == 1):
    print("You lose!")
  else:
    print("invalid choice try again!")
