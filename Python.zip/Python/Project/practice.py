# 4...
# a = float(input("enter first number: "))
# b = float(input("enter second number: "))
# temp = a
# a = b 
# b = temp

# print(f"{a}")
# print(f"{b}")

#5...

# KM = int(input("Enter Kilometer: "))

# meter = 1000 * KM
# centemeter = 100000 * KM
# inches = KM * 39370.1
# feet = KM * 3280.84

# print(f"Meter: {meter}")
# print(f"centemeter: {centemeter}")
# print(f"inches: {inches}")
# print(f"feet: {feet}")


# 6...

# P = int(input("enter value of P: "))
# R = int(input("enter value of R: "))
# T = int(input("enter value of T: "))

# SI = (P*R*T)/100

# print(f"simple interest: {SI}")

# 7...

# F = float(input("enter empreture in F: "))

# C = (F-32)*5/9

# print(f"Tempreture {round(C,2)}")

# 8...

# import math

# # Program to calculate the roots of a quadratic equation

# # Input: Coefficients a, b, and c
# a = float(input("Enter coefficient a: "))
# b = float(input("Enter coefficient b: "))
# c = float(input("Enter coefficient c: "))

# # Calculate the discriminant
# discriminant = b**2 - 4*a*c

# # Check the nature of the roots
# if discriminant > 0:
#     root1 = (-b + math.sqrt(discriminant)) / (2*a)
#     root2 = (-b - math.sqrt(discriminant)) / (2*a)
#     print(f"Two real and distinct roots: {root1} and {root2}")
# elif discriminant == 0:
#     root = -b / (2*a)
#     print(f"One real and equal root: {root}")
# else:
#     real_part = -b / (2*a)
#     imaginary_part = math.sqrt(abs(discriminant)) / (2*a)
#     print(f"Complex roots: {real_part} + {imaginary_part}i and {real_part} - {imaginary_part}i")

# 9...
# weight = float(input("enter your weight: "))
# height = float(input("enter your height: "))

# bmi = weight/(height**2)

# print(f"your BMI is: {bmi:.2f}")

# 1 Write a program to Check if a Number is Positive, Negative or 0.

# num = int(input("enter number to check wether number is positive or negative: "))
# if(num < 0):
#   print("number is nagetive")
# elif(num == 0):
#   print("number is zero")
# else:
#   print("number is positive")

# 2 Write a program to Check if a Number is Odd or Even.

# n = int(input("enter number: "))

# if(n % 2 == 0):
#   print("num is even")
# else:
#   print("odd")

# 4 Write a program to Display Calendar.
# import calendar

# year = int(input("enter year: "))
# month = int(input("enter month: "))

# print(calendar.month(year,month))

# 5 Write a program to Find the Square Root
# num = float(input("enter num: "))

# squarRoot = num**0.5

# print(f"{squarRoot:.2f}")

# string = input("enter string to check vowel or not: ").lower()

# if string in 'aeiou':
#   print(f"{string} is vowel")
# else:
#   print(f"{string} is not vowel")


# 15 Create a program that simulates a smart traffic light system. The program takes
# the following inputs:
# 1. Time of Day (morning, afternoon, evening, night).
# 2. Traffic Density (low, medium, high).
# 3. Emergency Vehicle Detected (yes or no).

# Based on these inputs, decide how long the green light should stay on.
# Rules:
# 1. If there’s an emergency vehicle, the green light stays on for 60 seconds,
# regardless of other inputs.
# 2. If it’s night and traffic density is low, the green light stays on for 15
# seconds.
# 3. During other times:
# o Low traffic: 30 seconds.
# o Medium traffic: 45 seconds.
# o High traffic: 60 seconds.

# def smart_traffic_light(time_of_the_day,traffic_dencity,emergency_vehicle):
#   if(emergency_vehicle == "yes"):
#     return 60
#   elif(time_of_the_day == "night" and traffic_dencity == "low"):
#     return 15
  
#   elif(traffic_dencity == "low"):
#     return 30
#   elif(traffic_dencity == "medium"):
#     return 45
#   else:
#     return 60
# time_of_the_day = input("enter time of the day(morning,afternoo,evening,night): ").lower()
# traffic_dencity = input("enter traffic dencity(low,medium,high): ").lower()
# emergency_vehicle = input("is emergency vehicle(yes/no): ").lower()
# smart_traffic_light = smart_traffic_light(time_of_the_day,traffic_dencity,emergency_vehicle)
# print(f"Green light should stay on for {smart_traffic_light} seconds.")

# 6. Write a program to calculate electricity bills based on usage:
#  First 100 units: $0.5/unit
#  Next 100 units (101–200): $0.75/unit
#  Beyond 200 units: $1.2/unit in python

# def calculate_bill(units):
#   if(units <= 100):
#     bill = units * 0.5
#   elif(units >= 101 and units <= 200):
#     bill = (units * 0.75) + (units * 0.5)
#   else:
#     bill = (units * 0.75) + (units * 0.5) + (units * 1.2)
#   return bill
# units = int(input("Enter the numbers of units: "))
# bill_amount = calculate_bill(units)
# print(f"Electricity bill: ${bill_amount}")

# def calculate_tax(salary):
#   if(salary < 30000):
#     tax = salary * 10/100
#   elif(salary >= 30000 and salary <= 60000):
#     tax = salary * 15/100
#   else:
#     tax = salary * 20/100
#   return tax

# salary = float(input("Enter your salary to calculate tax: "))
# tax = calculate_tax(salary)
# print(f"tax of your salary ${tax:.2f}")

# 8 Write a menu driven program for arithmetic operations...

# def add(a,b):
#   return a+b
# def sub(a,b):
#   return a-b
# def mul(a,b):
#   return a*b
# def div(a,b):
#   return a/b

# def calculate():
#   while True:
#     print("\nArithmetic operations menu: ")
#     print("1. addition")
#     print("2. subtraction")
#     print("3. multiplication")
#     print("4. division")
#     print("5. Exit")
    
#     choice = input("enter your choice (1-5): ")
    
#     if choice == '5':
#       print("Exiting the program")
#       break
    
#     num1 = float(input("enter first number: "))
#     num2 = float(input("enter second number: "))
    
#     if choice == '1':
#       print(f"result: {add(num1,num2)}")
#     elif choice == '2':
#       print(f"result: {sub(num1,num2)}")
#     elif choice == '3':
#       print(f"result: {mul(num1,num2)}")
#     elif choice == '4':
#       print(f"result: {div(num1,num2)}")
#     else:
#       print("invalid choice")
#     break
# calculate()

# 10 Write a program to simulate a bank ATM. The user is prompted for their PIN. If
# the PIN is correct, display a menu to perform operations like checking balance,
# withdrawing money, or depositing money.

# def atm():
#   correct_pin = "1234"
#   balance = 1000.0
  
#   pin = input("enter your pin: ")
#   if(pin != correct_pin):
#     print("invalid pin. Access denied")
#     return
  
#   while True:
#     print("\nATM menu: ")
#     print("1. check balance")
#     print("2. withdraw money")
#     print("3. deposit money")
#     print("4. Exit")
    
#     choice = input("enter your choice(1-4): ")
    
#     if(choice == '1'):
#       print(f"Your balance is: {balance:.2f}")
#       break
#     elif(choice == '2'):
#       amount = float(input("enter amount to withdraw: "))
#       if amount > balance:
#         print("Insufficient amount")
#       else:
#         balance -= amount
#         print(f"withdraw successful. New balance {balance:.2f}")
#       break
#     elif(choice == '3'):
#       amount = float(input("enter deposit amount: "))
#       balance += amount
#       print(f"Deposit successful. New balance {balance:.2f}")
#       break
#     elif(choice == 4):
#       print("Exiting ATM. Have good day!")
#       break
#     else:
#       print("Invalid choice try again!")
# atm()



# 13 Write a program to simulate an order system where customers can choose a
# category (starter, main course, dessert), and then select an item. Each item has a
# price, and the program calculates the total bill. in python

# def display_menu():
#     menu = {
#         "starter": {"Soup": 5.0, "Salad": 4.5},
#         "main course": {"Steak": 15.0, "Pasta": 12.0},
#         "dessert": {"Cake": 6.0, "Ice Cream": 4.0}
#     }
#     return menu

# def take_order():
#     menu = display_menu()
#     total_bill = 0
#     while True:
#         print("Categories: Starter, Main Course, Dessert")
#         category = input("Enter category (or 'done' to finish): ").lower()
#         if category == "done":
#             break
#         if category in menu:
#             print("Available items:")
#             for item, price in menu[category].items():
#                 print(f"{item}: ${price:.2f}")
#             item_choice = input("Enter item name: ")
#             if item_choice in menu[category]:
#                 total_bill += menu[category][item_choice]
#             else:
#                 print("Invalid item choice.")
#         else:
#             print("Invalid category.")
#     return total_bill

# # Example usage
# total = take_order()
# print(f"Total bill: ${total:.2f}")


# 14 Calculate shipping cost based on the weight of the package and the destination
# (domestic or international).
# Weight
# [Kg]

# Domestic
# Price

# International
# Price
# < 1 5 15
# 2 to 5 10 25
# 6 to 10 25 50
# >10 50 75

# def calculate_shipping_cost(weight,destination):
#   if(destination.lower() == "domestic"):
#     if weight < 1:
#       return 5
#     elif 2 <= weight <= 5:
#       return 10
#     elif 6<= weight <= 10:
#       return 25
#     else:
#       return 50
#   elif(destination.lower() == "international"):
#     if weight < 1:
#       return 15
#     elif 2 <= weight <= 5:
#       return 25
#     elif 6 <= weight <= 10:
#       return 50
#     else:
#       return 75
#   else:
#     return "Invalid destination"
  
# weight = float(input("enter package weight(kg): "))
# destination = input("Enter destination(domestic/international): ")
# cost = calculate_shipping_cost(weight,destination)
# print(f"The shipping cost is: {cost}$")

# 19 Create a program to play a Rock-Paper-Scissors game:
# 1. The user chooses Rock, Paper, or Scissors.
# 2. The computer makes a random choice.
# 3. The program determines the winner and displays the score after each
# round.
# 4. The game continues until the user decides to quit.

import random

def get_computer_choice():
    return random.choice(["rock", "paper", "scissors"])

def determine_winner(user_choice, computer_choice):
    if user_choice == computer_choice:
        return "It's a tie!"
    elif (user_choice == "rock" and computer_choice == "scissors") or \
         (user_choice == "scissors" and computer_choice == "paper") or \
         (user_choice == "paper" and computer_choice == "rock"):
        return "You win!"
    else:
        return "Computer wins!"

def play_game():
    user_score = 0
    computer_score = 0
    while True:
        user_choice = input("Enter Rock, Paper, or Scissors (or 'quit' to exit): ").lower()
        if user_choice == "quit":
            break
        if user_choice not in ["rock", "paper", "scissors"]:
            print("Invalid choice, try again.")
            continue
        
        computer_choice = get_computer_choice()
        print(f"Computer chose: {computer_choice}")
        result = determine_winner(user_choice, computer_choice)
        print(result)
        
        if "You win" in result:
            user_score += 1
        elif "Computer wins" in result:
            computer_score += 1
        
        print(f"Score - You: {user_score}, Computer: {computer_score}")

play_game()


    
  
      


