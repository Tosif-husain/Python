# problem 1...

# class programmer:
#   company = "microsoft"
#   def __init__(self,name,salary,pincode):
#     self.name = name
#     self.salary = salary
#     self.pincode = pincode
    
  
# p = programmer("tosif",120000,380028)
# print(p.name,p.salary,p.pincode,p.company)

# problem 2...

# class calculator:
#   def __init__(self,n):
#     self.n = n
    
#   def square(self):
#     print(f"The square is {self.n*self.n}")
  
#   def cube(self):
#     print(f"The cube is {self.n*self.n*self.n}")
    
#   def squareRoot(self):
#     print(f"The square root is {self.n**1/2}")

# result = calculator(2)
# result.square()
# result.cube()
# result.squareRoot()

# problem 3...

# class greet:
#   @staticmethod
#   def hello():
#     print("hello there")

# a = greet()
# a.hello()

# problem 4...

# from random import randint

# class train:
  
#   def __init__(self,trainNo):
#     self.trainNo = trainNo
    
#   def ticket_Book(self,fro,to):
#     print(f"ticket is booked for train no {self.trainNo} from {fro} to {to}")
    
#   def getStatus(self):
#     print(f"The train no {self.trainNo} on time and The number of seats are available {randint(10,100)}")
    
#   def getFare(self,fro,to):
#     print(f"Ticket is frair in Train no {self.trainNo} from {fro} to {to} is {randint(222,4444)} under the INDIAN RAILWAYS.")
    
# result = train(78231)

# result.ticket_Book("Mumbai","Goa")
# result.getStatus()
# result.getFare("Mumbai","Goa")




  

