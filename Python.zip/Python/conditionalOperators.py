age = int(input("Enter age: "))

if(age>=18):
  print("YES!")
elif(age<=0):
  print("You entered wrong age")
else:
  print("NO!")