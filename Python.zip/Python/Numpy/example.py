# import numpy as np

# array = np.array([1,2,3,4,5])
# print(array)
# print(array.shape)

# # Range
# np2 = np.arange(10)
# print(np2)

# # step 
# np3 = np.arange(0,10,2)
# print(np3)

# # zeros 
# np4 = np.zeros(10)
# print(np4)

# #multidimentional zeros 
# np5 = np.zeros((2,10))
# print(np5)

# # full
# np6 = np.full((10),6)
# print(np6)

# #multidimentional full
# np7 = np.full((2,10),6)
# print(np7)

# # convert python list to np 
# my_list = [1,2,3,4,5]
# np8 = np.array(my_list)
# print(np8)
# print(np8[0])

import numpy as np
# myArr = np.array([[1, 2, 3, 4], [4, 5, 6, 7]])
# print(myArr.size)# Output: 8
# print(myArr.shape)

lspace = np.linspace(1,50,12)
print(lspace)

